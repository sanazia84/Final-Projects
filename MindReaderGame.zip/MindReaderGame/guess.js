const numbers = []
const rows = 10;
const cols = 10;
let table = "";
let numberIndex = 0;

let special = '';
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const charactersLength = characters.length;
let counter1 = 0;
while (counter1 < 1) {
  special += characters.charAt(Math.floor(Math.random() * charactersLength));
  counter1 += 1;
}

for (let i = 0; i < 100; i++) {

    let result = '';
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      const charactersLength = characters.length;
      let counter = 0;
      while (counter < 1) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
      }

    if(i % 9 == 0)
    {
        numbers.push(i + ":" +special)

    }
    else
    {
        numbers.push(i + ":" +result)

    }

}

var specialCharacter = {
  name : special
};


for (let r = 0; r < rows; r++) {
  table += "<tr>";

  for(let c = 0; c < cols; c++) {
    table += `<td>${ numbers[numberIndex] }</td>`;
    numberIndex++;
  }
  table += "</tr>";
}

document.querySelector('.java-table').innerHTML = `<table border=1 >${ table }</table>`;
